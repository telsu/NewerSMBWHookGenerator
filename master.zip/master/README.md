# NewerSMBWHookGenerator
A very little software for making NewerSMBW Custom Sprite Hooks, works most of the time but not everytime.

Basically, if you want to make a NewerSMBW custom sprite, put in the software the actor you want it to replace, its name and its source file name.

You can also put a function that load the arc files you need.

Then after filling all the needed infos, the software will generate a hook for your sprite.
