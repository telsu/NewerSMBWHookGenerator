﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NewerSpriteHookGenerator
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (radioButton1.Checked == true) {
                    int number = int.Parse(textBox1.Text);
                    string Base = Convert.ToString(number, 16);
                    textBox2.Text = "0x" + Base;
                }
                else
                {
                    int number = int.Parse(textBox1.Text);
                    string Base = Convert.ToString(number, 16);
                    textBox2.Text = Base;
                }
               
            }
            catch
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
